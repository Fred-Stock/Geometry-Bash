﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;

namespace Geometry_Bash
{
    class Square : Player
    {
        

        private double timer;
        private FrameCounter frameCounter = new FrameCounter();
        private int[] currentStats;
        private bool attackActive;
        private double attackTime;
        private double cooldownTimer;
        private bool hit;
        private String direction = "";

        public Square(int player, Rectangle sAP, Texture2D texture, int windowWidth, int windowHeight, int[] stats) : base(texture, sAP, windowWidth, windowHeight)
        {
            // stats loads in H/D/S
            health = stats[0];
            moveSpeed = stats[2];
            currentStats = stats;

            //check if it is player one or two and then set the correct keybindings
            if (player == 1)
            {
                keyUp = Keys.W;
                keyDown = Keys.S;
                keyLeft = Keys.A;
                keyRight = Keys.D;
                
                keyAttack1 = Keys.Q;
                keyAttack2 = Keys.E;
            }

           if (player == 2)
           {
                keyUp = Keys.I;
                keyDown = Keys.K;
                keyLeft = Keys.J;
                keyRight = Keys.L;

                keyAttack1 = Keys.U;
                keyAttack2 = Keys.O;
           }

          
        }

        public override void Attack(Player player1, Player player2, KeyboardState kbState, double currentTime)
        {
            Square player = (Square)player1;
            hit = false;//boolean to prevent exseive hits

            Rectangle temp = player1.HitBox;
            Rectangle temp2 = player2.HitBox;

            int regMoveSpeed = currentStats[2];
            //when attack button is pressed
            if (kbState.IsKeyDown(player.keyAttack1) && !(prevKbState.IsKeyDown(player.keyAttack1)))
            {
                                            //check if already active
                                            //no -> attack  yes -> don't do anything
                                            //attack:
                                            //Lock movement, activate hitbox, set timer
                                            //after attack:
                                            //set regular movement, deactivate hitbox, set cooldown

                if (cooldownTimer <= 0 && !attackActive)
                 {
                    attackTime = currentTime;
                    timer = .5;
                    moveSpeed = currentStats[2] * 2;
                    attackActive = true;
                   
                    player1.HitBox = temp;
                    //New Movement
                    temp = hitBox;


                    moveLocked = true;
                    
                    if (kbState.IsKeyDown(keyRight))
                    {
                        direction = "right";
                    }
                    if (kbState.IsKeyDown(keyLeft))
                    {
                        direction = "left";
                    }

                    if (kbState.IsKeyDown(keyUp))
                    {
                        direction = "up";
                    }

                    if (kbState.IsKeyDown(keyDown))
                    {
                        direction = "down";
                    }



                }
            }
            //checks every frame
            if (attackActive & moveLocked)
            {
                if (direction == "right")
                {
                    temp.X += moveSpeed * 2;
                }
                if (direction == "left")
                {
                    temp.X -= moveSpeed * 2;
                }

                if (direction == "up")
                {
                    temp.Y -= moveSpeed * 2;
                }

                if (direction == "down")
                {
                    temp.Y += moveSpeed * 2;
                }

                hitBox = temp;
                //check for collision
                if (player1.Collision(player1, player2) && !hit)
                {
                    player2.Health -= 3;

                    hit = true;

                    //knockback
                    if (kbState.IsKeyDown(player.keyDown))
                        temp2.Y += 150;
                    if (kbState.IsKeyDown(player.keyUp))
                        temp2.Y -= 150;
                    if (kbState.IsKeyDown(player.keyRight))
                        temp2.X += 150;
                    if (kbState.IsKeyDown(player.keyLeft))
                        temp2.X -= 150;
                    player2.HitBox = temp2;
                    hit = false;
                }
            }
            
            if (currentTime >= attackTime + timer && attackTime != 0)
            {
                moveLocked = false;
                moveSpeed = currentStats[2];
                attackActive = false;
                attackTime = 0;
                cooldownTimer = 30 / 60;
            }

            
            cooldownTimer -= 1 / 60;
            prevKbState = kbState;
        }

      // public override void Attack2(Player player1, Player player2, KeyboardState kbstate)
      // {
      //     
      //     Square player = (Square)player1;
      //
      //     bool hit = false;
      //
      //     if (kbstate.IsKeyDown(player.keyAttack2) && !(prevKbState.IsKeyDown(player.keyAttack2)))
      //     {
      //         Rectangle temp = player1.HitBox;
      //         for (int i = 0; i < 300; i++)
      //         player1.Rotation += 1f;
      //
      //     }
      // }

        public override void Step(Player player1, Player player2, KeyboardState kbState, double currentTime)
        {
           
        }
    }
}
